const foodItem= [
    {
    id: 1,
    name: 'Serotonin Capsules',
    category : 'stress',
    rating : 4.3,
    price: 1320,
    img: 'images/biryani/depression-1.jpg',
    quantity: 1
},
{
    id: 2,
    name: 'ZOI Stress Support',
    category : 'stress',
    rating : 4.0,
    price: 1150,
    img: 'images/biryani/depression-2.jpg',
    quantity: 1
},
{
    id: 3,
    name: 'SimplyOne Tablets',
    category : 'stress',
    rating : 4.5,
    price: 1280,
    img: 'images/biryani/depression-3.jpg',
    quantity: 1
},
{
    id: 4,
    name: 'Regustress Capsules',
    category : 'stress',
    rating : 4.3,
    price: 1500,
    img: 'images/biryani/depression-4.jpg',
    quantity: 1
},
{
    id: 5,
    name: 'Mood Support',
    category : 'stress',
    rating : 3.6,
    price: 1000,
    img: 'images/biryani/depression-5.jpg',
    quantity: 1
},
{
    id: 6,
    name: 'Jiva Pills',
    category : 'stress',
    rating : 4.8,
    price: 1200,
    img: 'images/biryani/depression-6.jpg',
    quantity: 1
},
{
    id: 7,
    name: 'Winostress',
    category : 'stress',
    rating : 4.6,
    price: 1399,
    img: 'images/biryani/depression-7.jpg',
    quantity: 1
},
{
    id: 8,
    name: 'Solgar 5-HTP',
    category : 'stress',
    rating : 4.1,
    price: 2000,
    img: 'images/biryani/depression-8.jpg',
    quantity: 1
},
{
    id: 9,
    name: 'Ultimate Calm',
    category : 'stress',
    rating : 3.5,
    price: 1550,
    img: 'images/biryani/depression-9.jpg',
    quantity: 1
},
{
    id: 10,
    name: 'Bisosafe 2.5mg',
    category : 'hypertension',
    rating : 4.3,
    price: 1100,
    img: 'images/hypertension/ht-1.jpg',
    quantity: 1
},
{
    id: 11,
    name: 'Ayush-64 Tablet',
    category : 'hypertension',
    rating : 4.7,
    price: 1000,
    img: 'images/hypertension/ht-2.jpg',
    quantity: 1
},
{
    id: 12,
    name: 'Arjuna Tablet',
    category : 'hypertension',
    rating : 3.8,
    price: 1450,
    img: 'images/hypertension/ht-3.jpg',
    quantity: 1
},
{
    id: 13,
    name: 'Biogetica BipSolve',
    category : 'hypertension',
    rating : 3.6,
    price: 1200,
    img: 'images/hypertension/ht-4.jpg',
    quantity: 1
},
{
    id: 14,
    name: 'BloodNex Pills',
    category : 'hypertension',
    rating : 4.1,
    price: 1700,
    img: 'images/hypertension/ht-5.jpg',
    quantity: 1
},
{
    id: 15,
    name: 'Heartogen Plus',
    category : 'hypertension',
    rating : 4.5,
    price: 2000,
    img: 'images/hypertension/ht-6.jpg',
    quantity: 1
},
{
    id: 16,
    name: 'Sleep Tabs',
    category : 'sleep',
    rating : 4.7,
    price: 1550,
    img: 'images/sleep/sp-1.jpg',
    quantity: 1

},
{
    id: 17,
    name: 'Sleep Support',
    category : 'sleep',
    rating : 3.8,
    price: 1000,
    img: 'images/sleep/sp-2.jpg',
    quantity: 1
},
{
    id: 18,
    name: 'Sleep Easy',
    category : 'sleep',
    rating : 4.7,
    price: 1500,
    img: 'images/sleep/sp-3.jpg',
    quantity: 1

},
{
    id: 19,
    name: 'Blessful Sleep',
    category : 'sleep',
    rating : 2.9,
    price: 1250,
    img: 'images/sleep/sp-4.jpg',
    quantity: 1

},
{
    id: 20,
    name: 'Sleep N Restore',
    category : 'sleep',
    rating : 4.8,
    price: 1599,
    img: 'images/sleep/sp-5.jpg',
    quantity: 1
},
{
    id: 21,
    name: 'Jiva Ayurveda Sleep',
    category : 'sleep',
    rating : 3.0,
    price: 1275,
    img: 'images/sleep/sp-6.jpg',
    quantity: 1
},
{
    id: 22,
    name: 'Smart Greens',
    age: '32',
    category : 'sleep',
    rating : 4.5,
    price: 1150,
    img: 'images/sleep/sp-7.jpg',
    quantity: 1
},
{
    id: 23,
    name: 'HK Vitals',
    category : 'vitamins',
    rating : 3.2,
    price: 1800,
    img: 'images/vitamins/vt-1.jpg',
    quantity: 1
},
{
    id: 24,
    name: 'Vitamin D3',
    category : 'vitamins',
    rating : 3.9,
    price: 1275,
    img: 'images/vitamins/vt-2.jpg',
    quantity: 1
},
{
    id: 25,
    name: 'TrueBasics vitamin',
    category : 'vitamins',
    rating : 4.7,
    price: 1999,
    img: 'images/vitamins/vt-3.jpg',
    quantity: 1
},
{
    id: 26,
    name: 'One Daily vitamin',
    category : 'vitamins',
    rating : 3.5,
    price: 1200,
    img: 'images/vitamins/vt-4.jpg',
    quantity: 1
},
{
    id: 27,
    name: 'Zincovit',
    category : 'vitamins',
    rating : 4.0,
    price: 1000,
    img: 'images/vitamins/vt-5.jpg',
    quantity: 1
},
{
    id: 28,
    name: 'Myprotein Daily',
    category : 'vitamins',
    rating : 3.2,
    price: 1250,
    img: 'images/vitamins/vt-6.jpg',
    quantity: 1
},
{
    id: 29,
    name: 'Votum Nutrition',
    category : 'vitamins',
    rating : 3.9,
    price: 1000,
    img: 'images/vitamins/vt-7.jpg',
    quantity: 1
}
// ,
// {
//     id: 30,
//     name: 'Momos',
//     category : 'chinese',
//     rating : 4.3,
//     price: 8,
//     img: 'images/chinese/cabbage-momos-.jpg',
//     quantity: 1
// },
// {
//     id: 31,
//     name: 'Chicken Manchurian',
//     category : 'chinese',
//     rating : 4.3,
//     price: 7,
//     img: 'images/chinese/ChickenManchurian.jpg',
//     quantity: 1
// },
// {
//     id: 32,
//     name: 'Chili Chicken',
//     category : 'chinese',
//     rating : 4.3,
//     price: 5,
//     img: 'images/chinese/Chili-Chicken.jpg',
//     quantity: 1
// },
// {
//     id: 33,
//     name: 'Chowmein',
//     category : 'chinese',
//     rating : 4.3,
//     price: 16,
//     img: 'images/chinese/chowmin.jpg',
//     quantity: 1
// },
// {
//     id: 34,
//     name: 'Spring Roll',
//     category : 'chinese',
//     rating : 4.3,
//     price: 14,
//     img: 'images/chinese/spring-rolls.jpg',
//     quantity: 1
// },
// {
//     id: 35,
//     name: 'Szechuan Chicken',
//     category : 'chinese',
//     rating : 4.3,
//     price: 10,
//     img: 'images/chinese/szechuan-chicken.jpg',
//     quantity: 1
// },
// {
//     id: 36,
//     name: 'Fried Rice',
//     category : 'chinese',
//     rating : 4.3,
//     price: 8,
//     img: 'images/chinese/veg-fried-rice.jpg',
//     quantity: 1
// },
// {
//     id: 37,
//     name: 'Butter Masala Dosa',
//     category : 'south indian',
//     rating : 4.3,
//     price: 18,
//     img: 'images/south indian/Butter-Masala-Dosa.png',
//     quantity: 1
// },
// {
//     id: 38,
//     name: 'Idli',
//     category : 'south indian',
//     rating : 4.3,
//     price: 20,
//     img: 'images/south indian/idli-with-rice-flour.jpg',
//     quantity: 1
// },
// {
//     id: 39,
//     name: 'Masala Dosa',
//     category : 'south indian',
//     rating : 4.3,
//     price: 12,
//     img: 'images/south indian/masala-dosa.jpg',
//     quantity: 1
// },
// {
//     id: 40,
//     name: 'Mysore Bonda',
//     category : 'south indian',
//     rating : 4.3,
//     price: 10,
//     img: 'images/south indian/mysore-bonda.jpg',
//     quantity: 1
// },
// {
//     id: 41,
//     name: 'Onion Uttapam',
//     category : 'south indian',
//     rating : 4.3,
//     price: 15,
//     img: 'images/south indian/onion-uttapam.jpg',
//     quantity: 1
// },
// {
//     id: 42,
//     name: 'Plain Dosa',
//     category : 'south indian',
//     rating : 4.3,
//     price: 40,
//     img: 'images/south indian/plain-dosa.jpeg',
//     quantity: 1
// },
// {
//     id: 43,
//     name: 'Rava Uttapam',
//     category : 'south indian',
//     rating : 4.3,
//     price: 25,
//     img: 'images/south indian/Rava-Uttapam.jpg',
//     quantity: 1
// },
// {
//     id: 44,
//     name: 'Sambhar Vada',
//     category : 'south indian',
//     rating : 4.3,
//     price: 34,
//     img: 'images/south indian/sambhar-vada.jpg',
//     quantity: 1
// }
,
]

export {foodItem};